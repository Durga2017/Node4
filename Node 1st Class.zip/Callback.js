//Synchronous(Execute in REPL)

var myNumber = 1

function add(){
myNumber++
}//define the function
add()//run the function
console.log(myNumber)//logs out 2