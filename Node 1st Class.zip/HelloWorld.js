const http=require('http');
http.createServer((req,res)=>{

//1. Tell the browser everything is OK(status code 200), and the dat ais in plain text
res.writeHead(200,{
	'Content-Type':'text/plain'
});


//2. write the announced text to the body of the page
res.write('Hello World!\n');

//3. Tell the server that all of the response headers and the body have been sent
res.end();

}).listen(8080);

console.log('Server is running..');